package rdm.ordology.sunology;

import rdm.ordology.sunology.R;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.lang.Math;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.view.View;
import android.widget.AdapterView;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.DatePicker;

public class MainActivity extends Activity {

  double ZENITH_OFFICAL = 90.0;
  int SECONDS = 86400;
  int MEAN_EARTH_RADIUS = 6372000;
  private final static String FILE_NAME = "cities.csv";
  String[] Cities;
  double[] Latitudes;
  double[] Longitudes;
  double[] Altitudes;
  private File getExternalPath() {
    return new File(getExternalFilesDir(null), FILE_NAME);
  }
  public void getCities(){
    FileInputStream fin = null;
    try {
      File file = getExternalPath();
      if(!file.exists()) saveCities();
      fin = new FileInputStream(file);
      byte[] bytes = new byte[fin.available()];
      fin.read(bytes);
      String citiy = new String(bytes);
      String[] thecities = citiy.split("\n");
      int count = thecities.length;
      this.Cities = new String[count];
      this.Latitudes = new double[count];
      this.Longitudes = new double[count];
      this.Altitudes = new double[count];
      for(int i=0;i<count;i++){
        String[] thecity=thecities[i].split("@");
        this.Cities[i]=thecity[0];
        this.Latitudes[i]=Double.parseDouble(thecity[1]);
        this.Longitudes[i]=Double.parseDouble(thecity[2]);
        this.Altitudes[i]=Double.parseDouble(thecity[3]);
      }
    } catch(IOException ex) {

    } catch (NumberFormatException e) {
      this.Cities = getResources().getStringArray(R.array.cities);
      String[] latitudes = getResources().getStringArray(R.array.latitudes);
      String[] longitudes = getResources().getStringArray(R.array.longitudes);
      String[] altitudes = getResources().getStringArray(R.array.altitudes);
      for(int i=0;i<Cities.length;i++){
        this.Latitudes[i]=Double.parseDouble(latitudes[i]);
        this.Longitudes[i]=Double.parseDouble(longitudes[i]);
        this.Altitudes[i]=Double.parseDouble(altitudes[i]);
      }
    } finally {
      try{
        if(fin!=null) fin.close();
      } catch(IOException ex) {

      }
    }
  }
  public void saveCities(){
    FileOutputStream fos = null;
    try{
      fos = new FileOutputStream(getExternalPath());
      String[] latitudes = getResources().getStringArray(R.array.latitudes);
      String[] longitudes = getResources().getStringArray(R.array.longitudes);
      String[] altitudes = getResources().getStringArray(R.array.altitudes);
      String[] cities = getResources().getStringArray(R.array.cities);
      for(int i=0;i<cities.length;i++){
        String entry = cities[i]+"@"+latitudes[i]+"@"+longitudes[i]+"@"+altitudes[i]+"\n";
        fos.write(entry.getBytes());
      }
    } catch(IOException ex){

    } catch (NumberFormatException e) {

    } finally{
      try{
        if(fos!=null) fos.close();
      } catch(IOException ex){

      }
    }
  }
  public double geodethicAngle(double latitude, double altitude){
    if(altitude == 0) return 0.0;
    double r = (double) MEAN_EARTH_RADIUS;
    return Math.toDegrees(Math.acos(r / (r + altitude))) + (Math.sqrt(altitude) * (19.0 / 3600));
  }
  public double toRange_0_360(double value){
    while(0.0 > value)value += 360;
    while(value >= 360.0)value -= 360;
    return value;
  }
  public double trueLongitudeOfSunInDegrees(double t0){
    double M = (0.9856 * t0) - 3.289;
    double L = M + (1.916 * Math.sin(Math.toRadians((M))) + (0.020 * Math.sin(2 * Math.toRadians((M))) + 282.634));
    return toRange_0_360(L);
  }
  public String thetime(LocalDate date, double latitude, double longitude, double altitude){
    double zenith = ZENITH_OFFICAL + geodethicAngle(latitude, altitude);
    double doy = (double) date.getDayOfYear();
    double lngHour = longitude / 15;
    double t0 = doy + ((6 - lngHour) / 24);
    double L = trueLongitudeOfSunInDegrees(t0);
    double RA = Math.toDegrees(Math.atan(0.91764 * Math.tan(Math.toRadians(L))));
    RA = toRange_0_360(RA);
    double Lquadrant  = Math.floor(L / 90) * 90;
    double RAquadrant = Math.floor(RA / 90) * 90;
    RA = (RA + (Lquadrant - RAquadrant)) / 15;
    double sinDec = 0.39782 * Math.sin(Math.toRadians(L));
    double cosDec = Math.cos(Math.asin(sinDec));
    double latInRad = Math.toRadians(latitude);
    double cosH = (Math.cos(Math.toRadians(zenith)) - (sinDec * Math.sin(latInRad))) / (cosDec * Math.cos(latInRad));
    if ((Double.compare(cosH, 1.0) > 0) || (Double.compare(cosH, -1.0) < 0)) return "00:00";
    double H = Math.toDegrees(Math.acos(cosH));
    H = 360 - H;
    H = H / 15;
    double lmt = H + RA - (0.06571 * t0) - 6.622;
    if (Double.compare(0.0, lmt) > 0) lmt += 24;
    else if (Double.compare(24.0, lmt) <= 0) lmt -= 24;
    double ut =  lmt - lngHour;
    int tod = (int) Math.floor(ut * 3600);
    long secs = (long) doy * 86400 + tod;
    int scale = (int) Math.round(longitude/15);
    int thesecs = (int) Math.round(secs / 60.0) * 60;
    int mins = (int) Math.ceil(secs/60);
    int hour = ((mins/60)+scale)%24;
    int minute = mins%60;
    return ((hour>9)?String.valueOf(hour):"0"+String.valueOf(hour)) + ":" + ((minute>9)?String.valueOf(minute):"0"+String.valueOf(minute));
  }
  public void printAnswer(View view) {
    TextView selection = (TextView) findViewById(R.id.answer);
    DatePicker dateText = (DatePicker) this.findViewById(R.id.thedate);
    Spinner spinner = (Spinner) findViewById(R.id.city);
    double[] latitudes = this.Latitudes;
    double[] longitudes = this.Longitudes;
    double[] altitudes = this.Altitudes;
    String selected = spinner.getSelectedItem().toString();
    ArrayAdapter adapter = (ArrayAdapter) spinner.getAdapter();
    int position = adapter.getPosition(selected);
    String sunrise;
    int[] day = {dateText.getDayOfMonth(), (dateText.getMonth() + 1), dateText.getYear()};
    sunrise = thetime(LocalDate.of(day[2], day[1], day[0]), latitudes[position], longitudes[position], altitudes[position]);
    String answer = "Начало суток в " + sunrise;
    selection.setText(answer);
  }

  @Override
  public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    getCities();
    Spinner spinner = (Spinner) findViewById(R.id.city);
    ArrayAdapter<String> adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_item, this.Cities);
    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    spinner.setAdapter(adapter);
  }
}
